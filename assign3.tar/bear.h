/******************************************************
** Program: bear.cpp
** Author: chung yu yang
** Date: 2/14/2021
**Description: bear class's data and methods
**Input: class bear
** Output: bear data
******************************************************/
#ifndef BEAR_H
#define BEAR_H

using namespace std;

class bear : public Animal
{
	private:

	public:
		bear();

};

#endif

