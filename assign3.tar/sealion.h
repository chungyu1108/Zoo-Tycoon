/******************************************************
** Program: sealion.h
** Author: chung yu yang
** Date: 2/14/2021
**Description: sealion class's data and methods
**Input: class sealion
** Output: sealion data
******************************************************/
#ifndef SEALION_H
#define SEALION_H

using namespace std;

class sealion : public Animal
{
	private:

	public:
		sealion();

};

#endif