/******************************************************
** Program: tiger.h
** Author: chung yu yang
** Date: 2/14/2021
**Description: tiger class's data and methods
**Input: class tiger
** Output: tiger data
******************************************************/
#ifndef TIGER_H
#define TIGER_H

using namespace std;

class tiger : public Animal
{
	private:

	public:
		tiger();

};

#endif

